CarrierWave.configure do |config|
  # Agregado para cloudinary config.cache_storage = :file
  config.cache_storage = :file
end