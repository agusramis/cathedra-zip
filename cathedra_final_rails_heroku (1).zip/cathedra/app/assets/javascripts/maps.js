// Place all the behaviors and hooks related to the matching controller here.


//--- Gmap
//= require jquery.gmap/jquery.gmap.min
//--- jQuery Vector map
//= require ika.jvectormap/jquery-jvectormap-1.2.2.min
//= require ika.jvectormap/jquery-jvectormap-world-mill-en
//= require ika.jvectormap/jquery-jvectormap-us-mill-en