// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
// You can use CoffeeScript in this file: http://coffeescript.org/

//--- Sparklines
//= require jquery-sparkline/jquery.sparkline.min
//--- Flot
//= require flot/jquery.flot
//= require flot/jquery.flot.categories
//= require flot/jquery.flot.pie
//= require flot/jquery.flot.resize
//= require flot/jquery.flot.time
//= require jquery.flot.spline/jquery.flot.spline
//= require jquery.flot.tooltip/js/jquery.flot.tooltip.min
//--- ChartJS
///= require chart.js/dist/Chart
//--- Chartist
//= require chartist/dist/chartist
//--- Morris
//= require raphael/raphael
//= require morris.js.so/morris
//--- Rickshaw
//= require d3/d3
//= require rickshaw/rickshaw
// --- Knob
//= require jquery-knob/js/jquery.knob.js
// --- EasyPie
//= require easy-pie-chart/dist/jquery.easypiechart.min
