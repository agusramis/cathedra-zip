// This is a manifest file that'll be compiled into base.js, which will include all the files
// listed below.

//--- Modernizr
//= require modernizr
//--- Storage API
//= require js-storage/js.storage
//--- Screenfull
//= require screenfull/dist/screenfull
//--- jQuery
//= require jquery/dist/jquery
//--- Bootstrap
//= require popper.js/dist/umd/popper
//= require bootstrap/dist/js/bootstrap
