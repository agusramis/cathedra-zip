// Place all the behaviors and hooks related to the matching controller here.



// Sortable
//= require html5sortable/dist/html5sortable.js
//--- Nestable
//= require nestable/jquery.nestable
// --- Sweet Alert
//= require sweetalert2/dist/sweetalert2.min.js
