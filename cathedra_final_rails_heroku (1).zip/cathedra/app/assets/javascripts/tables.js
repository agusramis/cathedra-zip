// Place all the behaviors and hooks related to the matching controller here.



//--- Sparklines
//= require jquery-sparkline/jquery.sparkline.min
//--- Datatables
//= require datatables.net/js/jquery.dataTables
//= require datatables.net-bs4/js/dataTables.bootstrap4
//= require datatables.net-buttons/js/dataTables.buttons
//= require datatables.net-buttons-bs/js/buttons.bootstrap
//= require datatables.net-buttons/js/buttons.colVis
//= require datatables.net-buttons/js/buttons.flash
//= require datatables.net-buttons/js/buttons.html5
//= require datatables.net-buttons/js/buttons.print
//= require datatables.net-keytable/js/dataTables.keyTable
//= require datatables.net-responsive/js/dataTables.responsive
//= require datatables.net-responsive-bs/js/responsive.bootstrap
//= require jszip/dist/jszip
//= require pdfmake/build/pdfmake
//= require pdfmake/build/vfs_fonts
// --- BootGrid
//= require jquery-bootgrid/dist/jquery.bootgrid
//= require jquery-bootgrid/dist/jquery.bootgrid.fa
