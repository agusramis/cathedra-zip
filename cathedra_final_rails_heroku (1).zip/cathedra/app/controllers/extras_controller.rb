class ExtrasController < ApplicationController
  def mailbox
  end

  def timeline
  end

  def calendar
  end

  def invoice
  end

  def search
  end

  def todo
  end

  def profile
  end

  def contacts
  end

  def contact_details
  end

  def projects
  end

  def project_details
  end

  def team_viewer
  end

  def social_board
  end

  def vote_links
  end

  def bug_tracker
  end

  def faq
  end

  def help_center
  end

  def followers
  end

  def settings
  end

  def plans
  end

  def file_manager
  end

end
