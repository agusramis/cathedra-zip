class ElementsController < ApplicationController

  def button
  end

  def notification
  end

  def carousel
  end

  def spinner
  end

  def animation
  end

  def dropdown
  end

  def nestable
  end

  def sortable
  end

  def card
  end

  def portlet
  end

  def grid
  end

  def gridmasonry
  end

  def typography
  end

  def fonticons
  end

  def weathericons
  end

  def colors
  end

  def tour
  end

  def sweetalert
  end
end
