class BlogController < ApplicationController
  def blog
  end

  def blog_article_view
  end

  def blog_articles
  end

  def blog_post
  end
end
