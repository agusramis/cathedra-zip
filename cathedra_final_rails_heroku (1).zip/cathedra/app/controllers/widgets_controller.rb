class WidgetsController < ApplicationController
  protect_from_forgery with: :exception
  layout "application"
  def index
  end
end
