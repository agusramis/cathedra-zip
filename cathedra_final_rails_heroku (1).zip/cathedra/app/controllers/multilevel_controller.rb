class MultilevelController < ApplicationController
  def level1
  end

  def level3
  end
end
