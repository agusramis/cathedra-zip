class ForumController < ApplicationController
  def forum_categories
  end

  def forum_topics
  end

  def forum_discussion
  end

end
