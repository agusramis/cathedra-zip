class EcommerceController < ApplicationController
  def ecommerce_order_view
  end

  def ecommerce_orders
  end

  def ecommerce_product_view
  end

  def ecommerce_products
  end

  def ecommerce_checkout
  end
end
