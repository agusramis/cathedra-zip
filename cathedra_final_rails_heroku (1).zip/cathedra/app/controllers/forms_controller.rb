class FormsController < ApplicationController
  def standard
  end

  def extended
  end

  def validation
  end

  def upload
  end

  def wizard
  end

  def xeditable
  end

  def imgcrop
  end
end
