class TablesController < ApplicationController
  def standard
  end

  def extended
  end

  def datatable
  end

  def bootgrid
  end
end
