class MapsController < ApplicationController
  def google
  end

  def vector
  end
end
