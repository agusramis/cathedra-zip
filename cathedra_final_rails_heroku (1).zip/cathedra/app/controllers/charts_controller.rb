class ChartsController < ApplicationController
  def flot
  end

  def radial
  end

  def chartjs
  end

  def chartist
  end

  def morris
  end

  def rickshaw
  end
end
