module ConsultasHelper
end
