require 'test_helper'

class UsuarioMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
