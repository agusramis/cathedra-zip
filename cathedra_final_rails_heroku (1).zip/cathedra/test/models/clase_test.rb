require 'test_helper'

class ClaseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
