require 'test_helper'

class RegistroTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
