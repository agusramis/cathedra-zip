require 'test_helper'

class ExtrasHelperTest < ActionView::TestCase
end
