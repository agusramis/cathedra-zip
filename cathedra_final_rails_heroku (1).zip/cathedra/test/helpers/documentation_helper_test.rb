require 'test_helper'

class DocumentationHelperTest < ActionView::TestCase
end
