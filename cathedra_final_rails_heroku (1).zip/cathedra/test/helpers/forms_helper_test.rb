require 'test_helper'

class FormsHelperTest < ActionView::TestCase
end
