require 'test_helper'

class ElementsHelperTest < ActionView::TestCase
end
