require 'test_helper'

class MultilevelHelperTest < ActionView::TestCase
end
